
This directory contains utility scripts.

- `generatejson.py`:

	Generates request JSON for the
	[Cloud Vision API](https://cloud.google.com).
	See the [concepts](https://cloud.google.com/vision/docs/concepts) page
	in the documentation for more information.

