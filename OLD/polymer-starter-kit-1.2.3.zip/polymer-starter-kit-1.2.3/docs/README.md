# Recipes

* [Add ES2015 (formally ES6) support using Babel](add-es2015-support-babel.md)
* [Polymer Performance Recipe](polymer-perf.md)
* [Use PSK with Chrome Dev Editor](chrome-dev-editor.md)
* [Deploy to Github Pages](deploy-to-github-pages.md)
* [Deploy to Firebase using Pretty URLs](deploy-to-firebase-pretty-urls.md)
* [Deploy to Google App Engine](deploy-to-google-app-engine.md)
* [Use PSK for Mobile Chrome Apps](mobile-chrome-apps.md)
